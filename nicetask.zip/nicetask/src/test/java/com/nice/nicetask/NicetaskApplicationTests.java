package com.nice.nicetask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NicetaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
