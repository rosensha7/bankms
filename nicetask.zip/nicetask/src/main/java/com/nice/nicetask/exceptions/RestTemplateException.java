package com.nice.nicetask.exceptions;

public class RestTemplateException extends Exception {
    public RestTemplateException(String message) {
        super(message);
    }
}
