package com.nice.nicetask.exceptions;

public class FinancialInfoInvalidException extends Exception{

    public FinancialInfoInvalidException(String message) {super(message); }

}
