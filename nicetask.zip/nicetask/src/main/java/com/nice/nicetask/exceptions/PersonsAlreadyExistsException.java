package com.nice.nicetask.exceptions;

public class PersonsAlreadyExistsException extends Exception {
    public PersonsAlreadyExistsException(String message) { super(message); }
}
