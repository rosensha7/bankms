package com.nice.nicetask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NicetaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(NicetaskApplication.class, args);
	}

}
