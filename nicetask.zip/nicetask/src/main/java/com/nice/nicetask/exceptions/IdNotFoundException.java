package com.nice.nicetask.exceptions;

public class IdNotFoundException extends Exception {
    public IdNotFoundException(String message) {super(message); }
}
